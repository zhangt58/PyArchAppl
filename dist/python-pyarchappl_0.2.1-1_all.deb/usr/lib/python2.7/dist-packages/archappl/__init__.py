from archappl.client import *


__version__ = '0.2.1'
__author__ = 'Tong Zhang <zhangt@frib.msu.edu>'

__doc__ ="""archappl: Python interface of Archiver Appliance."""

